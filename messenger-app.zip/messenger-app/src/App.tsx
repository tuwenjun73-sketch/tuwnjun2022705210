import "./App.css";
import { useState } from "react";
import { BrowserRouter as Router, Route, Routes, useNavigate } from "react-router-dom";

// 模拟数据
const channels = [
  { id: 1, name: "频道 1", messages: ["Hello", "How are you?"] },
  { id: 2, name: "频道 2", messages: ["Hi there!", "Good evening"] },
  { id: 3, name: "频道 3", messages: ["Welcome!", "Let's chat"] },
];

// 登录页面组件
function LoginPage({ onLogin }: { onLogin: (username: string) => void }) {
  const [username, setUsername] = useState("");

  return (
    <div className="login-page">
      <h1>Login Page</h1>
      <input
        type="text"
        placeholder="请输入用户名"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <br />
      <br />
      <button onClick={() => onLogin(username)}>登录</button>
    </div>
  );
}

// 频道列表页面组件
function ChannelListPage({ onChannelClick }: { onChannelClick: (channelId: number) => void }) {
  const navigate = useNavigate(); // 获取 navigate 函数

  const handleChannelClick = (channelId: number) => {
    // 使用 navigate 跳转到消息页面
    navigate(`/messages/${channelId}`);
    onChannelClick(channelId); // 调用父组件的 onChannelClick 函数
  };

  return (
    <div className="channel-list-page">
      <h1>频道列表</h1>
      <ul>
        {channels.map((channel) => (
          <li key={channel.id} onClick={() => handleChannelClick(channel.id)}>
            {channel.name}
          </li>
        ))}
      </ul>
    </div>
  );
}

// 消息页面组件
function MessagesPage({ username, channelId }: { username: string; channelId: number }) {
  const channel = channels.find((channel) => channel.id === channelId);
  const navigate = useNavigate();

  if (!channel) return <div>频道不存在</div>;

  return (
    <div className="messages-page">
      <h1>{channel.name} 的消息</h1>
      <button onClick={() => navigate("/")}>返回</button>
      <ul>
        {channel.messages.map((message, index) => (
          <li
            key={index}
            className={username === "user" ? "message-right" : "message-left"}
          >
            {message}
          </li>
        ))}
      </ul>
    </div>
  );
}

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [currentChannelId, setCurrentChannelId] = useState<number | null>(null);

  // 登录处理函数
  const handleLogin = (username: string) => {
    setUsername(username);
    setLoggedIn(true);
  };

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            loggedIn ? (
              <ChannelListPage onChannelClick={setCurrentChannelId} />
            ) : (
              <LoginPage onLogin={handleLogin} />
            )
          }
        />
        <Route
          path="/messages/:channelId"
          element={currentChannelId ? (
            <MessagesPage username={username} channelId={currentChannelId} />
          ) : (
            <div>请选择频道</div>
          )}
        />
      </Routes>
    </Router>
  );
}

export default App;

